package lexico;

public class ItemLR0 {
    public int NumRegla;
    public int PosPunto;
    
    public ItemLR0(){
        this.NumRegla = -1;
        this.PosPunto = -1;
    }
    
    public ItemLR0(int NumRegla, int PosPunto){
        this.NumRegla = NumRegla;
        this.PosPunto = PosPunto;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 89 * hash + this.NumRegla;
        hash = 89 * hash + this.PosPunto;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final ItemLR0 other = (ItemLR0) obj;
        if (this.NumRegla != other.NumRegla) {
            return false;
        }
        return this.PosPunto == other.PosPunto;
    }
    
}

