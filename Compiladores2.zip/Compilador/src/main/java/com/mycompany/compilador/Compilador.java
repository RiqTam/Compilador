import java.awt.*;
import java.awt.event.*;
import lexico.Thompson;
import lexico.AFN;
import lexico.AFD;
import ventanas.Pantalla;
import java.util.ArrayList;

public class Compilador
{
    public static void main(String[] args) throws Exception {
        ArrayList<AFN> afns = new ArrayList<AFN>();
        Thompson thomp = new Thompson();
        AFD afd = new AFD();
        Pantalla p = new Pantalla(afns,thomp,afd);
        p.setVisible(true);
    }
	
}