package lexico;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;


public class LR0Sj {
    public int j;
    public List<ItemLR0> Sj;
    
    public LR0Sj(){
        this.j = -1;
        Sj = new ArrayList<ItemLR0>();
        Sj.clear();
    }
}


