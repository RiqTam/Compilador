package sintactico;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import lexico.ItemLR0;
import lexico.LR0Sj;

public class LR {
    ArrayList<Regla> reglas;
    
    public String[][] crearTabla(ArrayList<Regla> reglas){
        this.reglas = reglas;
        
        List<String> Follow = new ArrayList<String>();
        
        List<Integer> coorx = new ArrayList<Integer>();
        List<Integer> coory = new ArrayList<Integer>();
        List<Integer> val = new ArrayList<Integer>();
        
        List<String> V = new ArrayList<String>();
        V.clear();
        List<String> simbolosN = new ArrayList<String>();
        List<String> simbolosT = new ArrayList<String>();

        for(Regla regla : reglas){
            for(Nodo nodo : regla.getSimbolos()){
                if(nodo.getTerminal()){
                    simbolosT.add(nodo.getSimbolo());
                }else{
                    simbolosN.add(nodo.getSimbolo());
                }
            }
        }
        LL ll = new LL();
        simbolosN = ll.quitarDuplicados(simbolosN);
        simbolosT = ll.quitarDuplicados(simbolosT);
        simbolosT.remove("epsilon");
        V.addAll(simbolosN);
        V.addAll(simbolosT);
        V.add("$");
        int j;
        boolean existe;
        
        List<LR0Sj> C = new ArrayList<LR0Sj>();
        
        LR0Sj ConjSj = new LR0Sj();
        LR0Sj ConjSjAux;
        
        List<ItemLR0> ConjItems = new ArrayList<ItemLR0>();
        
        List<ItemLR0> SjAux = new ArrayList<ItemLR0>();
        
        Queue<LR0Sj> Q = new LinkedList<LR0Sj>(); 
        
        
        ConjItems.clear();
        ConjItems.add(new ItemLR0(0,0));
        
        j=0;
        ConjSj.Sj = CerraduraLR0(ConjItems);
        ConjSj.j=j;
        C.add(ConjSj);
        Q.add(ConjSj);
        
        j++;
        while(!Q.isEmpty()){
            ConjSj = Q.remove();
            for(int i=0;i<V.size();i++){
                SjAux = IrA(ConjSj.Sj, V.get(i));
                if(SjAux.size()==0){
                    continue;
                }
                    
                existe = false;
                for(LR0Sj ElemSj : C){
                    if(ElemSj.Sj.size()==SjAux.size()){
                        if(ElemSj.Sj.equals(SjAux)){
                            existe = true;
                            coorx.add(i+1);
                            coory.add(ConjSj.j+1);
                            val.add(ElemSj.j);
                            break;
                        }
                    }
                }
                if(!existe){
                    ConjSjAux = new LR0Sj();
                    ConjSjAux.Sj = SjAux;
                    ConjSjAux.j = j;
                    j++;
                    C.add(ConjSjAux);
                    Q.add(ConjSjAux);
                    coorx.add(i+1);
                    coory.add(ConjSj.j+1);
                    val.add(ConjSjAux.j);
                }
            }
        }
        
        String[] X = V.toArray(new String[V.size()]);
        String tabla[][] = new String[C.size()+1][X.length+1];
        
        for(int i=1;i<=C.size();i++){ 
            for(int n=1;n<=X.length;n++){
                tabla[i][n] = "-10";
            }
        }
        
        for(int i=1;i<=X.length;i++){ 
            tabla[0][i] = X[i-1];
        }
        
        for(int i=1;i<=C.size();i++){
            tabla[i][0] = Integer.toString(C.get(i-1).j);
        }
        
        List<Nodo> N = new ArrayList<Nodo>();
        List<Integer> x = new ArrayList<Integer>();
        List<Integer> y = new ArrayList<Integer>();
        List<String> v = new ArrayList<String>();
        for(LR0Sj ElemSj : C){
            for(ItemLR0 i: ElemSj.Sj){
                N = reglas.get(i.NumRegla).getSimbolos();               
                if(i.PosPunto == N.size()){
                    Follow = ll.siguiente(reglas.get(i.NumRegla).getLadoIzquierdo(), reglas);
                    for(String s: Follow){
                        for(int m=0;m<V.size();m++){
                            if(s==V.get(m)){
                                x.add(ElemSj.j+1);
                                y.add(m+1);
                                if(i.NumRegla==0){
                                    v.add("Aceptar");
                                }else{
                                    v.add("R"+i.NumRegla);
                                }
                                
                                break;
                            }
                        }
                    }
                }
            }
        }
        
        for(int i=0;i<val.size();i++){ 
            tabla[coory.get(i)][coorx.get(i)] = Integer.toString(val.get(i));
        }
        
        for(int i=0;i<v.size();i++){ 
            tabla[x.get(i)][y.get(i)] = v.get(i);
        }

        return tabla;
    }
    
    public List<String> quitarDuplicados(List<String> lista){
        List<String> listaN = new ArrayList<String>();
        for(String elemento : lista){
            if(!listaN.contains(elemento)){
                listaN.add(elemento);
            }
        }
        return listaN;
    }

    public List<ItemLR0> CerraduraLR0(List<ItemLR0> C) {
        List<ItemLR0> R = new ArrayList<ItemLR0>();
        List<ItemLR0> Temporal = new ArrayList<ItemLR0>();
        ItemLR0 Aux = new ItemLR0();
        List<Nodo> Lista = new ArrayList<Nodo>();
        Nodo N;
        R.clear();
        if(C.size()==0)
            return R;
        R.addAll(C);
        Temporal.clear();
        for(ItemLR0 I: C){
            Lista = reglas.get(I.NumRegla).getSimbolos();
            if(I.PosPunto < Lista.size()){
                N = Lista.get(I.PosPunto);
                if(!N.getTerminal()){
                    for(int k=0;k<reglas.size();k++){
                        if(reglas.get(k).getLadoIzquierdo().equals(N.getSimbolo())){
                            Aux = new ItemLR0(k,0);
                            if(!Contiene(C,Aux))
                                Temporal.add(Aux);
                        }
                    }
                }
            }    
        }
        R.addAll(CerraduraLR0(Temporal));
        return R;
    }

    public List<ItemLR0> IrA(List<ItemLR0> C, String simb) {
        List<ItemLR0> R = new ArrayList<ItemLR0>();
        R = CerraduraLR0(Mover(C, simb));
        return R;
    }
    
    boolean Contiene(List<ItemLR0> C, ItemLR0 Aux){
        for(ItemLR0 I : C)
            if(I.NumRegla == Aux.NumRegla && I.PosPunto == Aux.PosPunto)
                return true;
        return false;
    }
    
    public List<ItemLR0> Mover(List<ItemLR0> C, String simbolo) {
        List<ItemLR0> R = new ArrayList<ItemLR0>();
        List<Nodo> Lista = new ArrayList<Nodo>();
        Nodo N;
        R.clear();
        for(ItemLR0 I : C){
            Lista = reglas.get(I.NumRegla).getSimbolos();
            if(I.PosPunto < Lista.size()){
                N = Lista.get(I.PosPunto);
                if(N.getSimbolo().equals(simbolo))
                    R.add(new ItemLR0(I.NumRegla, I.PosPunto+1));
            }
        }
        return R;
    }
}
