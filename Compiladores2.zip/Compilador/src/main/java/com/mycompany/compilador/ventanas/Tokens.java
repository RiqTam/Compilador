package ventanas;
import java.awt.*;
import java.awt.event.*;
import lexico.Thompson;
import lexico.AFN;
import lexico.AFD;
import java.util.ArrayList;
import java.util.HashSet;
import javax.swing.DefaultComboBoxModel;
import lexico.Estado;

public class Tokens extends javax.swing.JFrame {

    HashSet<AFN> agregarAFNs;
    ArrayList<AFN> seleccion;
    ArrayList<AFN> afns;
    AFN afn;
    AFD afd;
    int i;
    String texto;
    
    public Tokens(HashSet<AFN> N, ArrayList<AFN> S, ArrayList<AFN> A, AFD F){
        this.agregarAFNs = N; 
        this.seleccion = S;
        this.afns = A;
        this.afd = F;  
        this.i = 0;
        afn = seleccion.get(i);
        texto = "Introduzca el token del AFN " + afns.indexOf(afn);
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        valor = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jLabel1.setText(texto);

        jButton1.setText("Token");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel1)
                .addGap(35, 35, 35)
                .addComponent(valor, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(144, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton1)
                .addGap(41, 41, 41))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(valor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(jButton1)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jLabel1.getAccessibleContext().setAccessibleName(texto);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        int token = Integer.parseInt(valor.getText());
        valor.setText(null);
        HashSet<Estado> eliminarEdos = new HashSet<Estado>();
        HashSet<Estado> agregarEdos = new HashSet<Estado>();
        for(Estado edoAcept : afn.getEdosAcept()){
            eliminarEdos.add(edoAcept);
            edoAcept.setToken(token);
            agregarEdos.add(edoAcept);
        }
        for(Estado edo : eliminarEdos){
            afn.removeEdo(edo);
            afn.removeEdoAcept(edo);
        }
        for(Estado edo : agregarEdos){
            afn.setEdo(edo);
            afn.setEdoAcept(edo);
        }
        agregarAFNs.add(afn);
        i++;
        
        if(i==seleccion.size()){
            afns.removeAll(seleccion);
            afns.add(afd.unirAFNs(agregarAFNs));
            dispose();
            
        }
        if(i<seleccion.size()){
            afn = seleccion.get(i);
            texto = "Introduzca el token del AFN " + afns.indexOf(afn);
            jLabel1.setText(texto);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JTextField valor;
    // End of variables declaration//GEN-END:variables
}
