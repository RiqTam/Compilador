package sintactico;

import java.util.ArrayList;
import java.util.List;
import lexico.ItemLR0;

public class TablaF {
    public List<String> opc;
    
    public TablaF(){
        
    }
}
