package sintactico;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.Stack;
import javax.swing.table.DefaultTableModel;
import lexico.AnalizadorLexico;

public class AnalizadorLR0 {
    public boolean analizar(String cadena, String[][] tabla, ArrayList<Regla> reglas, String afd, List<Integer> diccionario, DefaultTableModel analizar){
        Stack<String> pilaReglas = new Stack<String>();
        Queue<Integer> filaTokens = new LinkedList<>();

        List<String> simbolosN = new ArrayList<String>();
        List<String> simbolosT = new ArrayList<String>();

        for(Regla regla : reglas){
            for(Nodo nodo : regla.getSimbolos()){
                if(nodo.getTerminal()){
                    simbolosT.add(nodo.getSimbolo());
                }else{
                    simbolosN.add(nodo.getSimbolo());
                }
            }
        }
        LL ll = new LL();
        simbolosN = ll.quitarDuplicados(simbolosN);
        simbolosT = ll.quitarDuplicados(simbolosT);
        simbolosT.add("$");
        simbolosT.remove("epsilon");
        
        AnalizadorLexico lexico = new AnalizadorLexico(afd, cadena);
        int tokenLex = -10;
        while(tokenLex != 0){
            tokenLex = lexico.yylex();
            filaTokens.add(tokenLex);
        }
        
        pilaReglas.push(tabla[1][0]); 

        while(!pilaReglas.empty()){
            String printReglas = "" + pilaReglas;
            String printTokens = "" + filaTokens; 
            int tokenAct = filaTokens.peek();
            String simbAct = pilaReglas.peek();
            
            for(int i=1;i<tabla.length;i++){
                if(tabla[i][0].equals(simbAct)){
                    for(int j=1;j<tabla[0].length;j++){

                        if(tokenAct==0){
                            if(tabla[0][j].equals("$")){
                                if(tabla[i][j].charAt(0)=='R'){
                                    analizar.addRow(new String[]{printReglas,printTokens,tabla[i][j]});
                                    int r = 2*reglas.get(Character.getNumericValue(tabla[i][j].charAt(1))).getSimbolos().size();
                                    for(int n=0;n<r;n++){
                                        pilaReglas.pop();
                                    }
                                    String x = pilaReglas.peek();
                                    pilaReglas.add(reglas.get(Character.getNumericValue(tabla[i][j].charAt(1))).getLadoIzquierdo());
                                    String y = pilaReglas.peek();
                                    for(int i2=1;i2<tabla.length;i2++){
                                        if(tabla[i2][0].equals(x)){
                                            for(int j2=1;j2<tabla[0].length;j2++){
                                                if(tabla[0][j2].equals(y)){
                                                    pilaReglas.add(tabla[i2][j2]);
                                                }
                                            }
                                        }
                                    }
                                    if(tabla[i][j].equals("-10")){
                                        return false;
                                    }
                                    if(tabla[i][j].equals("Aceptar")){
                                        return true;
                                    } 
                                }else{
                                    analizar.addRow(new String[]{printReglas,printTokens,tabla[i][j]});
                                    pilaReglas.add(String.valueOf(tokenAct));
                                    pilaReglas.add(tabla[i][j]);
                                    filaTokens.poll();
                                    if(tabla[i][j].equals("-10")){
                                        return false;
                                    }
                                    if(tabla[i][j].equals("Aceptar")){
                                        return true;
                                    }   
                                }
                            }
                        }
                        else if(tabla[0][j].equals(simbolosT.get(diccionario.indexOf(tokenAct)))){
                            if(tabla[i][j].charAt(0)=='R'){
                                analizar.addRow(new String[]{printReglas,printTokens,tabla[i][j]});
                                int r = 2*reglas.get(Character.getNumericValue(tabla[i][j].charAt(1))).getSimbolos().size();
                                for(int n=0;n<r;n++){
                                    pilaReglas.pop();
                                }
                                String x = pilaReglas.peek();
                                pilaReglas.add(reglas.get(Character.getNumericValue(tabla[i][j].charAt(1))).getLadoIzquierdo());
                                String y = pilaReglas.peek();
                                for(int i2=1;i2<tabla.length;i2++){
                                    if(tabla[i2][0].equals(x)){
                                        for(int j2=1;j2<tabla[0].length;j2++){
                                            if(tabla[0][j2].equals(y)){
                                                pilaReglas.add(tabla[i2][j2]);
                                            }
                                        }
                                    }
                                }
                                if(tabla[i][j].equals("-10")){
                                    return false;
                                }
                                if(tabla[i][j].equals("Aceptar")){
                                    return true;
                                } 
                            }else{
                                analizar.addRow(new String[]{printReglas,printTokens,tabla[i][j]});
                                pilaReglas.add(String.valueOf(tokenAct));
                                pilaReglas.add(tabla[i][j]);
                                filaTokens.poll();
                                if(tabla[i][j].equals("-10")){
                                    return false;
                                }
                                if(tabla[i][j].equals("Aceptar")){
                                    return true;
                                } 
                            }
                        }
                        
                    }
                }
            }
        }
        return false;
    } 
}
